package com.example.allo.service;

import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class InMemoryDataStore {

    private final Map<String, Object> store = new ConcurrentHashMap<>();

    public void put(String key, Object value) {
        // Wrap value into an immutable container if it's a Map, otherwise store as-is
        if (value instanceof Map) {
            store.put(key, Collections.unmodifiableMap((Map) value));
        } else {
            store.put(key, value);
        }
    }

    public Object get(String key) {
        return store.get(key);
    }

    public boolean contains(String key) {
        return store.containsKey(key);
    }
}
