package com.example.allo.controller;

import com.example.allo.service.InMemoryDataStore;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/finance/data")
public class FinanceController {

    private final InMemoryDataStore store;

    public FinanceController(InMemoryDataStore store) {
        this.store = store;
    }

    @GetMapping("/{resourceType}")
    public ResponseEntity<?> getData(@PathVariable String resourceType) {
        if (!store.contains(resourceType)) {
            return ResponseEntity.notFound().build();
        }
        Object data = store.get(resourceType);
        return ResponseEntity.ok(data);
    }
}
