package com.example.allo.runner;

import com.example.allo.fetcher.IDRDataFetcher;
import com.example.allo.service.InMemoryDataStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class DataLoaderRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DataLoaderRunner.class);

    private final Map<String, IDRDataFetcher> fetchers;
    private final InMemoryDataStore store;

    public DataLoaderRunner(Map<String, IDRDataFetcher> fetchers, InMemoryDataStore store) {
        this.fetchers = fetchers;
        this.store = store;
    }

    @Override
    public void run(ApplicationArguments args) {
        log.info("Starting DataLoaderRunner - loading resources");
        for (Map.Entry<String, IDRDataFetcher> e : fetchers.entrySet()) {
            String key = e.getKey();
            try {
                Object data = e.getValue().fetchData();
                store.put(key, data);
                log.info("Loaded resource {}", key);
            } catch (Exception ex) {
                log.error("Failed to load {}: {}", key, ex.getMessage());
            }
        }
        log.info("DataLoaderRunner finished");
    }
}
