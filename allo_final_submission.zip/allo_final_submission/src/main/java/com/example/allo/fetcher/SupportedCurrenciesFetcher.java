package com.example.allo.fetcher;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;

@Component("supported_currencies")
public class SupportedCurrenciesFetcher implements IDRDataFetcher {

    private final WebClient client;

    public SupportedCurrenciesFetcher(WebClient client) {
        this.client = client;
    }

    @Override
    public Object fetchData() {
        Map<String, Object> raw = client.get()
                .uri("/currencies")
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                .block();

        if (raw == null) return Map.of();
        return raw;
    }
}
