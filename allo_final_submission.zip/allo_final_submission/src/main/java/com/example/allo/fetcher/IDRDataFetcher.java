package com.example.allo.fetcher;

public interface IDRDataFetcher {
    /**
     * Fetch data (called during startup). Implementations must return a JSON-like object (Map or DTO).
     */
    Object fetchData();
}
