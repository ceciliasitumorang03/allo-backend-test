package com.example.allo.fetcher;

import com.example.allo.util.SpreadCalculator;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;

@Component("latest_idr_rates")
public class LatestIdrRatesFetcher implements IDRDataFetcher {

    private final WebClient client;

    public LatestIdrRatesFetcher(WebClient client) {
        this.client = client;
    }

    @Override
    public Object fetchData() {
        Map<String, Object> raw = client.get()
                .uri("/latest?base=IDR")
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                .block();

        if (raw == null) return Map.of();

        Object ratesObj = raw.get("rates");
        if (!(ratesObj instanceof Map)) return raw;

        Map<String, Object> rates = (Map<String, Object>) ratesObj;
        Object usdObj = rates.get("USD");
        double rateUsd = 0.0;
        if (usdObj != null) {
            try {
                rateUsd = Double.parseDouble(usdObj.toString());
            } catch (NumberFormatException e) {
                rateUsd = 0.0;
            }
        }
        double spread = SpreadCalculator.calculateSpread("ceciliasitumorang");
        double usdBuySpread = (rateUsd == 0.0) ? 0.0 : (1.0 / rateUsd) * (1.0 + spread);

        raw.put("USD_BuySpread_IDR", usdBuySpread);
        raw.put("spread_factor", spread);
        return raw;
    }
}
