package com.example.allo.util;

public class SpreadCalculator {

    /**
     * Calculate spread factor based on GitHub username as described:
     * sum unicode of lowercase username % 1000, then divide by 100000.0
     */
    public static double calculateSpread(String username) {
        if (username == null) return 0.0;
        String lower = username.toLowerCase();
        int sum = 0;
        for (char c : lower.toCharArray()) {
            sum += (int) c;
        }
        int mod = sum % 1000;
        return mod / 100000.0;
    }
}
