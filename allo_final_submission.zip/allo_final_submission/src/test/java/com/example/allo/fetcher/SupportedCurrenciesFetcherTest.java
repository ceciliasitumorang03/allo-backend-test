package com.example.allo.fetcher;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class SupportedCurrenciesFetcherTest {

    @Test
    public void testSupportedFetch() {
        WebClient client = Mockito.mock(WebClient.class);
        WebClient.RequestHeadersUriSpec uriSpec = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec reqSpec = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec respSpec = Mockito.mock(WebClient.ResponseSpec.class);

        when(client.get()).thenReturn(uriSpec);
        when(uriSpec.uri(anyString())).thenReturn(reqSpec);
        when(reqSpec.retrieve()).thenReturn(respSpec);

        Map<String, Object> mockResponse = Map.of("USD", "United States Dollar", "IDR", "Indonesian Rupiah");
        when(respSpec.bodyToMono(any(ParameterizedTypeReference.class))).thenReturn(Mono.just(mockResponse));

        SupportedCurrenciesFetcher fetcher = new SupportedCurrenciesFetcher(client);
        Object result = fetcher.fetchData();
        assertNotNull(result);
        assertTrue(result instanceof Map);
    }
}
