package com.example.allo.fetcher;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class LatestIdrRatesFetcherTest {

    @Test
    public void testLatestFetchAndSpread() {
        WebClient client = Mockito.mock(WebClient.class);
        WebClient.RequestHeadersUriSpec uriSpec = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec reqSpec = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec respSpec = Mockito.mock(WebClient.ResponseSpec.class);

        when(client.get()).thenReturn(uriSpec);
        when(uriSpec.uri(anyString())).thenReturn(reqSpec);
        when(reqSpec.retrieve()).thenReturn(respSpec);

        Map<String, Object> mockResponse = Map.of(
                "base", "IDR",
                "rates", Map.of("USD", 0.000062)
        );

        when(respSpec.bodyToMono(any(ParameterizedTypeReference.class))).thenReturn(Mono.just(mockResponse));

        LatestIdrRatesFetcher fetcher = new LatestIdrRatesFetcher(client);
        Object result = fetcher.fetchData();
        assertNotNull(result);
        assertTrue(result instanceof Map);

        Map map = (Map) result;
        assertTrue(map.containsKey("USD_BuySpread_IDR"));
        assertTrue(map.containsKey("spread_factor"));
        double spread = (double) map.get("spread_factor");
        assertTrue(spread >= 0.0 && spread < 0.01);
    }
}
