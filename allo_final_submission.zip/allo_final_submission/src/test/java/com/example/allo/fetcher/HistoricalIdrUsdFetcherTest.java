package com.example.allo.fetcher;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class HistoricalIdrUsdFetcherTest {

    @Test
    public void testHistoricalFetch() {
        WebClient client = Mockito.mock(WebClient.class);
        WebClient.RequestHeadersUriSpec uriSpec = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec reqSpec = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec respSpec = Mockito.mock(WebClient.ResponseSpec.class);

        when(client.get()).thenReturn(uriSpec);
        when(uriSpec.uri(anyString())).thenReturn(reqSpec);
        when(reqSpec.retrieve()).thenReturn(respSpec);

        Map<String, Object> mockResponse = Map.of("rates", Map.of("2024-01-01", Map.of("USD", 0.000062)));

        when(respSpec.bodyToMono(any(ParameterizedTypeReference.class))).thenReturn(Mono.just(mockResponse));

        HistoricalIdrUsdFetcher fetcher = new HistoricalIdrUsdFetcher(client);
        Object result = fetcher.fetchData();
        assertNotNull(result);
        assertTrue(result instanceof Map);
    }
}
