package com.example.allo.runner;

import com.example.allo.fetcher.IDRDataFetcher;
import com.example.allo.service.InMemoryDataStore;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Map;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class DataLoaderRunnerIntegrationTest {

    @MockBean(name = "latest_idr_rates")
    private IDRDataFetcher latest;

    @MockBean(name = "historical_idr_usd")
    private IDRDataFetcher historical;

    @MockBean(name = "supported_currencies")
    private IDRDataFetcher supported;

    @Autowired
    private InMemoryDataStore store;

    @Test
    public void testRunnerLoadsData() {
        when(latest.fetchData()).thenReturn(Map.of("ok", true));
        when(historical.fetchData()).thenReturn(Map.of("hist", true));
        when(supported.fetchData()).thenReturn(Map.of("curr", true));

        // Runner executes during context startup; assert store contains keys
        assertTrue(store.contains("latest_idr_rates"));
        assertTrue(store.contains("historical_idr_usd"));
        assertTrue(store.contains("supported_currencies"));
        assertNotNull(store.get("latest_idr_rates"));
    }
}
