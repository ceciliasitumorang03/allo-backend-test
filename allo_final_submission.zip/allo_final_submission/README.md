# Allo Bank Take-Home Test — Final Submission (Prepared)

This repository is a production-like solution for the Allo Bank Backend Developer take-home test.

## Highlights
- Strategy Pattern implemented for three resources: `latest_idr_rates`, `historical_idr_usd`, `supported_currencies`.
- `WebClient` created using a `FactoryBean` (`WebClientFactory`), base URL externalized in `application.yml`.
- `ApplicationRunner` (`DataLoaderRunner`) loads all resources exactly once at startup.
- Immutable/Thread-safe in-memory store (`InMemoryDataStore`) holds loaded data; controller reads from this store.
- Spread calculation uses GitHub username `ceciliasitumorang` per test instructions.

## Run
Requirements: Java 11+, Maven.

```bash
mvn clean package
java -jar target/allo-0.0.1-SNAPSHOT.jar
```

Endpoints:
- `GET /api/finance/data/latest_idr_rates`
- `GET /api/finance/data/historical_idr_usd`
- `GET /api/finance/data/supported_currencies`

## Architecture (brief)
```
[Application Start] -> DataLoaderRunner ---fetchers---> External API (frankfurter.app)
                                   |
                                   v
                           InMemoryDataStore (immutable)
                                   |
                           FinanceController -> clients
```

## Architectural Rationale (short answers)
1. Strategy Pattern: decouples resource-specific fetching logic from controller, easy to extend with new resources.
2. FactoryBean for WebClient: allows custom instantiation and externalized configuration; conforms to test constraint.
3. ApplicationRunner: guarantees startup-time data ingestion and ordering, preferable over @PostConstruct for long-running IO.

## Tests
- Unit tests for fetchers (mock WebClient)
- Integration test for DataLoaderRunner (mock beans)

## PR notes
See `PR_DESCRIPTION.md` for a ready-to-paste PR description and rationale.
