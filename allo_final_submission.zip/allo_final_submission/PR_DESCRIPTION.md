PR Title: feat: Implement IDR rate aggregator (latest, historical, currencies)

Summary:
- Implemented Strategy Pattern with three fetchers: latest_idr_rates, historical_idr_usd, supported_currencies.
- WebClient is created using a FactoryBean and base URL is externalized in application.yml.
- DataLoaderRunner loads all resources on startup and stores them in an immutable in-memory store.
- Controller serves data from the in-memory store at GET /api/finance/data/{resourceType}.
- Spread calculation uses GitHub username 'ceciliasitumorang'.

Architectural Rationale:
1) Strategy Pattern justification:
   The strategy pattern provides clear separation of concerns: each fetcher encapsulates its own external API interaction and transformation logic. This makes adding or modifying resources a matter of adding or updating a single component, improving maintainability and testability.

2) FactoryBean justification:
   Using FactoryBean allows custom construction logic for the WebClient and externalizes the base URL configuration. This satisfies the test constraint and centralizes client configuration (timeouts, headers) in one place, avoiding duplication.

3) ApplicationRunner justification:
   ApplicationRunner ensures the data ingestion happens at the correct lifecycle moment (after context is ready) and only once. This approach is more explicit and reliable for IO-bound initialization than @PostConstruct.

Testing:
- Unit tests mock WebClient for stable, fast verification.
- Integration test verifies runner populates the in-memory store.

Branch: feat/idr-rate-aggregator
